#adjust port number if necessary
rmiregistry -J-Djava.rmi.server.useCodebaseOnly=false 1099 &
